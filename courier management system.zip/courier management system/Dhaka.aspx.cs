﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Dhaka : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
        con.Open();
        String insert = "insert into warehouse(rphn,trackID,rname,branch) values (@rphn,@trackID,@rname,@branch)";
        SqlCommand command = new SqlCommand(insert, con);
        command.Parameters.AddWithValue("@rphn", rphn.Text);
        command.Parameters.AddWithValue("@trackID", trackID.Text);
        command.Parameters.AddWithValue("@rname", rname.Text);
        command.Parameters.AddWithValue("@branch", branch.SelectedItem.ToString());
        command.ExecuteNonQuery();
        

        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
        con1.Open();
        String update = "update tracking_status set status = '" + status.SelectedItem.ToString() + "'where trackID='" + trackID.Text +"'";
        SqlCommand command1 = new SqlCommand(update, con1);
        command.ExecuteNonQuery();
        con1.Close();
        con.Close();
    }
}