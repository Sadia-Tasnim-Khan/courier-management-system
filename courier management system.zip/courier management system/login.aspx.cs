﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
            con.Open();
            String user_check = "select count(*) from User_details where loginID= '" + uname.Text + "'";
            SqlCommand command = new SqlCommand(user_check, con);
            int temp = Convert.ToInt32(command.ExecuteScalar().ToString());

            if (temp == 1)
            {
                con.Open();
                string checkPasswordQuery = "select pass from User_details where pass= '" + password.Text + "'";
                SqlCommand passComm = new SqlCommand(checkPasswordQuery, con);
                string pass = passComm.ExecuteScalar().ToString().Replace(" ","");
                if (pass == password.Text)
                {
                    Response.Write("Password is Correct");
                    Response.Redirect("Track.aspx");
                    
                }
                else
                {
                    Response.Write("Password is Not Correct");
                    
                }


            }
            else
            {
                Response.Write("Username is Not Correct");
                
            }

            con.Close();
        
    }
    protected void password_TextChanged(object sender, EventArgs e)
    {

    }
}