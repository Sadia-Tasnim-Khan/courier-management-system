﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        /*try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
            con.Open();
            String find = "select * from User_info where (Username like '%' + @name + '%' or Number like '%' + @number + '%')";
            SqlCommand command = new SqlCommand(find, con);

            command.Parameters.Add("@name", search_box.Text);
            command.Parameters.Add("@number", search_box.Text);

            command.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = command;
            DataSet 

            Response.Write("Registration is Succesful");

            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.ToString());
        }*/
    }
}