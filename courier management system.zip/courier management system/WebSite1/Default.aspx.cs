﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack){
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
            con.Open();
            String user_check = "select count(*) from User_info where Username= '"+uname.Text+"'";
            SqlCommand command = new SqlCommand(user_check, con);
            int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
            if (temp == 1){
                Response.Write("Usename Already Exits");
            }

            con.Close();
        }


    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
    protected void signup_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
            con.Open();
            String insert = "insert into User_info (Name,Username,Email,Password,Number,City) values (@name, @uname, @email, @pass, @number, @city )";
            SqlCommand command = new SqlCommand(insert, con);
            command.Parameters.AddWithValue("@name", name.Text);
            command.Parameters.AddWithValue("@uname", uname.Text);
            command.Parameters.AddWithValue("@email", email.Text);
            command.Parameters.AddWithValue("@pass", pass.Text);
            command.Parameters.AddWithValue("@number", phone.Text);
            command.Parameters.AddWithValue("@city", city.SelectedItem.ToString());

            command.ExecuteNonQuery();
            //Response.Redirect("Admin.aspx");
            Response.Write("Registration is Succesful");
     
            con.Close();
        }
        catch (Exception ex) {
            Response.Write("Error: " + ex.ToString());
        }
    }
}