﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Order : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void confrim_cal_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
        con.Open();

        String insert = "insert into Order_info(sn,su ,sa, sp, ra,rp, rn, trakID, paymeny, shipping, weight, city) values (@sn,@su, @sa, @sp, @ra,@rp, @rn, @trakID, @paymeny, @shipping, @weight, @city)";
        
        SqlCommand command = new SqlCommand(insert, con);
        
        command.Parameters.AddWithValue("@sn", sn.Text);
        command.Parameters.AddWithValue("@su", su.Text);
        command.Parameters.AddWithValue("@sa", sa.Text);
        command.Parameters.AddWithValue("@sp", sp.Text);
        command.Parameters.AddWithValue("@ra", ra.Text);
        command.Parameters.AddWithValue("@rp", rp.Text);
        command.Parameters.AddWithValue("@rn", rn.Text);
        command.Parameters.AddWithValue("@trakID", trackID.Text);
        command.Parameters.AddWithValue("@paymeny", payment.SelectedItem.ToString());
        command.Parameters.AddWithValue("@shipping", shipping.SelectedItem.ToString());
        command.Parameters.AddWithValue("@weight", weight.Text);
        command.Parameters.AddWithValue("@city", city.SelectedItem.ToString());
        command.ExecuteNonQuery();
        con.Close();

        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_Registration"].ConnectionString);
        con1.Open();
        String insert1 = "insert into tracking_status(trackID) values (@trackID)";
        SqlCommand command1 = new SqlCommand(insert1, con1);
        command1.Parameters.AddWithValue("@trackID", trackID.Text);
        command1.ExecuteNonQuery();
        con1.Close();
        

    }
    protected void shipping_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}